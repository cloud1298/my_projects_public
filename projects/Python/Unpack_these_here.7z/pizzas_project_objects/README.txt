# Pizza Menu Simulator

## Overview
A Python command-line program that simulates a pizza menu. It includes predefined pizzas and allows users to create custom pizzas by selecting ingredients from a list, then displays all pizzas sorted by ingredient count and name.

## Features
- Predefined pizzas with set ingredients and prices
- Custom pizza creation with user-selected ingredients
- Vegetarian pizza identification
- Sorting by number of ingredients and pizza name
- Price calculation for custom pizzas

## Prerequisites
- Python 3.x

## Usage
1. Run the script: python pizza_menu.py
2. For each custom pizza (2 are created):
   - View the list of 32 available ingredients
   - Add ingredients by typing their names (case-insensitive)
   - Press ENTER with no input to finish adding ingredients
3. See all pizzas displayed with names, prices, ingredients, and vegetarian status.

## Technical Details
- Built with Python
- Uses object-oriented programming with `Pizza` and `CustomPizza` classes
- Custom pizzas have a base cost of $7.00 plus $1.20 per ingredient
- 32 predefined ingredients available for custom pizzas
- Sorting via `sort()` with a custom key function

## Notes
- Predefined pizzas: "4 cheese" (vegetarian), "Capricciosa", "Mafioso"
- Two custom pizzas are created per run
- Ingredients must match the predefined list exactly
- Duplicate ingredients are allowed in custom pizzas