

LIST_OF_INGREDIENTS = [
    "mozzarella",
    "pepperoni",
    "mushrooms",
    "onion",
    "sausage",
    "bacon",
    "green olives",
    "green pepper",
    "parmesan",
    "ham",
    "pineapple",
    "spinach",
    "artichokes",
    "chicken",
    "jalapeno",
    "sun-dried tomatoes",
    "feta cheese",
    "blue cheese",
    "anchovies",
    "arugula",
    "eggplant",
    "goat cheese",
    "ricotta",
    "garlic",
    "bell pepper",
    "pesto",
    "prosciutto",
    "brie",
    "gouda",
    "tomato",
    "tabasco",
    "black olives"
]


class Pizza:
    def __init__(self, name: str, price: float, ingredients: tuple, vegetarian: bool = False):
        self.name = name
        self.price = price
        self.ingredients = ingredients
        self.vegetarian = vegetarian

    def display(self):
        vege_text = " - VEGETARIAN"
        empty_text = ""

        print()
        print(
            f"PIZZA {self.name}: ${self.price:.2f}{vege_text if self.vegetarian else empty_text}"
        )
        print(", ".join(self.ingredients))


class CustomPizza(Pizza):
    BASE_COST = 7.0
    INGREDIENT_COST = 1.2
    last_number = 0

    def __init__(self):
        CustomPizza.last_number += 1
        self.number = CustomPizza.last_number
        super().__init__(f"Custom {self.number}", 0.00, [])

        self.ask_for_ingredients()
        self.calculate_price()

    def ask_for_ingredients(self):
        print(f"\nList of ingredients for pizza nr. {self.number}: \n")
        for i, ingredient in enumerate(LIST_OF_INGREDIENTS):
            print(f"{i}. {ingredient}")

        while True:
            custom_ingredient = input(
                "\nAdd an ingredient from the list (Or press ENTER to continue): ").strip().lower()

            if custom_ingredient == "":
                return

            if custom_ingredient not in LIST_OF_INGREDIENTS:
                print("Invalid ingredient. Please try again.")
                continue

            self.ingredients.append(custom_ingredient)

            print(
                f"You have {len(self.ingredients)} ingredient(s): {', '.join(self.ingredients)}."
            )

    def calculate_price(self):
        self.price = (
            self.BASE_COST + len(self.ingredients) * self.INGREDIENT_COST
        )


def main():
    pizzas = create_pizzas()

    pizzas.sort(key=sort_pizzas)

    for pizza in pizzas:
        pizza.display()


def create_pizzas():
    pizza1 = Pizza(
        "4 cheese",
        9.00,
        ("blue cheese", "brie", "gouda", "mozzarella"),
        True,
    )

    pizza2 = Pizza(
        "Capricciosa",
        10.00,
        ("tomato", "mozzarella", "ham", "olives", "mushrooms", "artichokes")
    )

    pizza3 = Pizza(
        "Mafioso",
        15.00,
        ("tomato", "mozzarella", "pepperoni", "tabasco", "ham", "black olives")
    )

    pizza4 = CustomPizza()
    pizza5 = CustomPizza()

    return [pizza1, pizza2, pizza3, pizza4, pizza5]


def sort_pizzas(e):
    return (len(e.ingredients), e.name)


if __name__ == "__main__":
    main()
