import pytest
import project
import sys
import pandas as pd
from datetime import datetime
from typing import List, Tuple, Optional
from babel.numbers import format_currency
from unittest.mock import patch

from project import get_amount
from project import get_float_with_two_decimals
from project import get_choice
from project import get_max_display
from project import get_yes_no_choice
from project import get_date


def mock_get_float_with_two_decimals(_prompt):
    # Simulate user input based on the prompt
    return 100.00


def create_DataFrame():
    transactions = pd.DataFrame(
        columns=["name", "category", "amount", "date"]
    )

    return transactions


def test_get_amount_income(monkeypatch):
    monkeypatch.setattr(
        project,
        "get_float_with_two_decimals",
        mock_get_float_with_two_decimals
    )

    result = get_amount("income")
    expected_result = format_currency(100.00, "USD", locale="en_US")
    assert result == expected_result


def test_get_amount_outcome(monkeypatch):
    # Mock the get_float_with_two_decimals function
    monkeypatch.setattr(
        project,
        "get_float_with_two_decimals",
        mock_get_float_with_two_decimals
    )

    result = get_amount("outcome")
    expected_result = format_currency(-100.00, "USD", locale="en_US")
    assert result == expected_result


def test_get_float_with_two_decimals_valid_input(monkeypatch):
    monkeypatch.setattr("builtins.input", lambda _: "23.45")
    result = get_float_with_two_decimals("Enter amount: ")

    assert result == 23.45


def test_get_float_with_two_decimals_invalid_input(monkeypatch, capsys):
    inputs = iter(["invalid", "23.456", "-2", "23.45"])
    monkeypatch.setattr("builtins.input", lambda _: next(inputs))

    result = get_float_with_two_decimals("Enter amount: ")
    captured = capsys.readouterr()

    assert "Invalid value. Enter a number with two or one decimal digits. Example: 12.34" in captured.out
    assert result == 23.45


def test_get_float_with_two_decimals_large_value(monkeypatch, capsys):
    inputs = iter(["100000000000", "23.45"])
    monkeypatch.setattr("builtins.input", lambda _: next(inputs))

    result = get_float_with_two_decimals("Enter amount: ")
    captured = capsys.readouterr()

    assert "Invalid value. Max amount is $99 000 000 000." in captured.out
    assert result == 23.45


def test_get_choice_valid(monkeypatch):
    monkeypatch.setattr("builtins.input", lambda _: "1")

    result = get_choice("Choose", ["input", "output"])

    assert result == "input"


def test_get_choice_invalid_number(monkeypatch, capsys):
    inputs = iter(["0", "3", "2"])
    monkeypatch.setattr("builtins.input", lambda _: next(inputs))

    result = get_choice("Choose", ["input", "output"])
    captured = capsys.readouterr()

    assert "Invalid choice. Please enter a number from the list." in captured.out
    assert result == "output"


def test_get_choice_invalid_string(monkeypatch, capsys):
    inputs = iter(["invalid", "2"])
    monkeypatch.setattr("builtins.input", lambda _: next(inputs))

    result = get_choice("Choose", ["input", "output"])
    captured = capsys.readouterr()

    assert "Invalid input. Please enter a number." in captured.out
    assert result == "output"


def get_max_display_valid(monkeypatch):
    monkeypatch.setattr("builtins.input", lambda _: 10)

    result = get_max_display()

    assert result == 10


def get_max_display_invalid(monkeypatch, capsys):
    inputs = iter(["invalid", "-1", "10"])
    monkeypatch.setattr("builtins.input", lambda _: next(inputs))

    result = get_max_display()
    captured = capsys.readouterr()

    assert "Invalid amount. You must provide a positive number bigger than 0.\n" in captured.out
    assert result == 10


def test_get_yes_no_choice_valid(monkeypatch):
    monkeypatch.setattr("builtins.input", lambda _: "YES")

    result_yes = get_yes_no_choice("Do you want to continue?")
    assert result_yes == "yes"

    monkeypatch.setattr("builtins.input", lambda _: "no")

    result_no = get_yes_no_choice("Do you want to continue?")
    assert result_no == "no"


def test_get_yes_no_choice_invalid(monkeypatch, capsys):
    inputs = iter(["invalid", "y", "N", "no"])
    monkeypatch.setattr("builtins.input", lambda _: next(inputs))

    result = get_yes_no_choice("Do you want to continue?")
    assert result == "no"


def test_get_date_valid(monkeypatch):
    monkeypatch.setattr('builtins.input', lambda _: "2024-02-01")

    result = get_date("Enter a date:")

    assert result == datetime(2024, 2, 1)


def test_get_date_invalid(monkeypatch, capsys):
    inputs = iter(["invalid-date", "2024", "2024.04", "2024-04", "2024-09-18"])
    monkeypatch.setattr('builtins.input', lambda _: next(inputs))

    result = get_date("Enter a date:")
    captured = capsys.readouterr()

    assert "Invalid date format. Please use the format 'YYYY-MM-DD'." in captured.out
    assert result == datetime(2024, 9, 18)
