# Finance Manager
#### Video Demo:  https://youtu.be/r-zJ8Pahw-I
#### Description:

This program is creating a financial data where you can add transactions, view transactions and generate a report based on the specific day or days.

I will explain here every piece of code.

## *main()*:
```
try:
    transactions = pd.read_csv("transactions.csv")
except FileNotFoundError:
    transactions = pd.DataFrame(
        columns=["name", "category", "amount", "date"]
    )

while True:
    print_options()
    user_decision = input("Enter the number: ").strip()

    match user_decision:
        case "1":
            name, category, amount, date = get_transaction_details()

            transactions = add_transaction(
                transactions, name, category, amount, date
            )
        case "2":
            view_transaction(transactions)
        case "3":
            generate_report(transactions)
        case "4":
            print("Exiting program...")
            sys.exit(0)
        case _:
            print("\nInvalid option. Please try again.\n")
```
**This is the main function. It manages the usage of the program.**
#### Part 1:
```
try:
    transactions = pd.read_csv("transactions.csv")
except FileNotFoundError:
    transactions = pd.DataFrame(
        columns=["name", "category", "amount", "date"]
    )
```
**Read csv file and set it into transactions variable.**
**If the file does not exists, then we are creating a DataFrame with columns named "name", "category", "amount" and "date".**
#### Part 2:
```
while True:
    print_options()
    user_decision = input("Enter the number: ").strip()

    match user_decision:
        case "1":
            name, category, amount, date = get_transaction_details()

            transactions = add_transaction(
                transactions, name, category, amount, date
            )
        case "2":
            view_transaction(transactions)
        case "3":
            generate_report(transactions)
        case "4":
            print("Exiting program...")
            sys.exit(0)
        case _:
            print("\nInvalid option. Please try again.\n")
```

**This is a while - True loop to make the main part. User can choose the action and end the program via 4th option.**
**Use another function to print the options user have.**
**Take the input from the user and make it into variable.**
**I used match-case to get the proper result. I thought that match-case would be better than if-else in this case.**
**"Option 1 will get the transaction details. First the program is trying to get name, category, amount and date from "get_transaction_details" function. Then it adds a new transaction via "add_transaction" function.**
**Option 2 will display the transaction list on the screen. It takes the "transactions" DataFrame as an argument.**
**Option 3 will generate the report about transactions. It will display what is the max income and outcome. This function will also take a "transactions" as an argument.**
**Option 4 will just end the program.**
**If user makes a mistake or writes an invalid number, then an error will display and the program will ask for an option again.**

## *print_options() -> None:*:
```
print("Choose the number:\n")
print("1. Create a new transaction")
print("2. View transaction list")
print("3. Generate a financial report")
print("4. Exit program\n")
```
**This function is for displaying the options that user can choose from. I wanted to place everything in the separate function just to make less mess.**
**Those are the options:**
1. *Create a new transaction*
2. *View transaction list*
3. *Generate a financial report*
4. *Exit program*

## *get_transaction_details() -> tuple*:
```
name = input("Enter the transaction name: ").strip()

category = get_category_choice()

amount = get_amount(category)

date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

return name, category, amount, date
```
**Here the program takes the data required to fill the DataFrame.**
**It takes the name from the input.**
**Then it gets the category from the "get_category_choice" function.**
**Next it gets the amount from the "get_amount" function. "get_amount" will use the category as an argument.**
**The last variable is the date. Program is just taking current date to add it to the transaction. Then it is formatting it to the "YYYY-MM-DD HH:MM:SS" format.**
**At last the program is returning those variables.**

## *get_amount(category: str) -> float*:
```   
amount = get_float_with_two_decimals("Enter the amount of dollars: ")
print()

if category == "income":
    return format_currency(amount, "USD", locale="en_US")
elif category == "outcome":
    return format_currency(-amount, "USD", locale="en_US")
```
**Get a value as amount and then return it properly formatted (based on the category).**
#### Part 1: 
```
amount = get_float_with_two_decimals("Enter the amount of dollars: ")
print()
```
**Get the amount from another function.**
**Print an empty line for the style.**
#### Part 2:
```
if category == "income":
    return format_currency(amount, "USD", locale="en_US")
elif category == "outcome":
    return format_currency(-amount, "USD", locale="en_US")
```
**Format the amount to dollars based on the category.**

## *get_float_with_two_decimals(prompt: str) -> float*:
```
pattern = r"^\d+(\.\d{1,2})?$"

while True:
    user_input = input(prompt)
    if re.match(pattern, user_input):
        value = float(user_input)
        try:
            if value <= 99000000000:
                return value

            raise ValueError
        except ValueError:
            print("Invalid value. Max amount is $99 000 000 000.")
    else:
        print(
            "Invalid value. Enter a number with two or one decimal digits. Example: 12.34"
        )
```
**This function takes the pattern to find the number that matches the amount of money (two decimals max). Then it is trying to make it into float and eventually checks for errors.**
#### Part 1:
```
pattern = r"^\d+(\.\d{1,2})?$"
```
**This is the pattern for checking if user output is exactly a number with maximum of two decimals.**
#### Part 2:
```
while True:
    user_input = input(prompt)
    if re.match(pattern, user_input):
        value = float(user_input)
        try:
            if value <= 99000000000:
                return value

            raise ValueError
        except ValueError:
            print("Invalid value. Max amount is $99 000 000 000.")
    else:
        print(
            "Invalid value. Enter a number with two or one decimal digits. Example: 12.34"
        )
```
**Here is the "while" loop for checking the user input. First the program takes the prompt from the arguments. Next if the pattern matches the user input, then program is changing this input into the float value. Then it checks for errors. Max value is 99 000 000 000. If the input doesn't match the pattern, then we have an error information.**

## *get_category_choice() -> str*:
```
options = ["income", "outcome"]
prompt = "Choose a category: "

return get_choice(prompt, options)
```
**Return the result of the "get_choice" function with options and prompt as arguments.**

## *add_transaction(transactions: pd.DataFrame, name: str, category: str, amount: format_currency, date: str) -> pd.DataFrame*:
```
new_transaction = {
    "name": name,
    "category": category,
    "amount": amount,
    "date": date,
}

transactions.loc[len(transactions)] = new_transaction

transactions.to_csv("transactions.csv", index=False)

return transactions
```
**Make a new transaction based on the function arguments.**
**Insert new transaction at the beginning of the transactions data.**
**Save new transactions to the csv file.**
**Return the "transactions" DataFrame.**

## *view_transaction(transactions: pd.DataFrame) -> None*:
```
filter, sort = user_display_customize(transactions)

max_rows = get_max_display()

print("\n")
if filter:
    filtered_data = transactions

    for col, val in filter:
        filtered_data = filtered_data[filtered_data[col].str.contains(
            val, case=False, na=False
        )]

    if filtered_data.empty:
        print("\nNO DATA FOUND\n")
    else:
        if sort:
            print(
                filtered_data.sort_values(
                    by=sort[0], ascending=sort[1]
                ).head(max_rows).to_string(
                    index=False
                )
            )

        else:
            print(
                filtered_data.head(max_rows).to_string(
                    index=False
                )
            )
elif sort:
    print(
        transactions.sort_values(
            by=sort[0], ascending=sort[1]
        ).head(max_rows).to_string(
            index=False
        )
    )
else:
    print(
        transactions.head(max_rows).to_string(
            index=False
        )
    )
print("\n")
```
**This function displays the data based on the filters and applied sort.**
#### Part 1:
```
filter, sort = user_display_customize(transactions)

max_rows = get_max_display()

print("\n")
```
**Get any filter and sort data from the "user_display_customize" function.**
**Let the user decide how many rows the program should display.**
**Print the empty line for the styling.**
#### Part 2:
```
if filter:
    filtered_data = transactions

    for col, val in filter:
        filtered_data = filtered_data[filtered_data[col].str.contains(
            val, case=False, na=False
        )]

    if filtered_data.empty:
        print("\nNO DATA FOUND\n")
    else:
        if sort:
            print(
                filtered_data.sort_values(
                    by=sort[0], ascending=sort[1]
                ).head(max_rows).to_string(
                    index=False
                )
            )

        else:
            print(
                filtered_data.head(max_rows).to_string(
                    index=False
                )
            )
```
**If there is a filter, then use it to filter data. New filtered data is saved in "filtered_data" variable, but first just add "transactions" DataFrame as this.**
**Loop between every filter and apply it to filtered_data.**
**If filtered data is empty, then print "NO DATA FOUND".**
**Then look for sorting. If there is any sort command, print the sorted data. Otherwise just print the filtered data/**
#### Part 3:
```
elif sort:
    print(
        transactions.sort_values(
            by=sort[0], ascending=sort[1]
        ).head(max_rows).to_string(
            index=False
        )
    )
```
**If there is no filter data, but there is a sort data, then just print the sorted data.**
#### Part 4:
```
else:
    print(
        transactions.head(max_rows).to_string(
            index=False
        )
    )
print("\n")
```
**If there is no filter or sort to apply, then print the data as it is. Add an empty line at the end for the styling.**

## *get_max_display()*:
```
while True:
    try:
        rows_to_display = int(
            input("\nHow many rows do you want to display: ")
        )
        if rows_to_display > 0:
            return rows_to_display

        raise ValueError
    except ValueError:
        print("Invalid amount. You must provide a positive number bigger than 0.\n")
```
**Program gets the input from the user. It must be int, because the error will raise otherwise. Of course rows to display should be more than 0.**

## *user_display_customize(transactions: pd.DataFrame) -> tuple[tuple[str, str], tuple[str, str]]*:
```
filter, sort = None, None

if get_yes_no_choice("\nDo you want to filter the database?\nEnter 'yes' or 'no': ") == "yes":
    filter = user_filter_transaction(transactions)

if get_yes_no_choice("\nDo you want to sort the database?\nEnter 'yes' or 'no': ") == "yes":
    sort = user_sort_transaction(transactions)

return filter, sort
```
**Function takes the filter and sort data and returns it.**
**At first set filter and sort to None.**
**Thanks to "get_yes_no_choice" function, get the filter information and set it to filter variable.**
**Do the same with the sort.**

## *get_yes_no_choice(prompt: str) -> str*:
```
error_message = "Please, enter a valid answer."

while True:
    user_choice = input(prompt).strip().lower()
    if user_choice in ["yes", "no"]:
        return user_choice
    else:
        print(error_message)
```
**Function gets the choice from the user. This choice should be "yes" or "no". Print error message otherwise.**
```
error_message = "Please, enter a valid answer."
```
**Here is the variable handling an error information.**
```
while True:
    user_choice = input(prompt).strip().lower()
    if user_choice in ["yes", "no"]:
        return user_choice
    else:
        print(error_message)
```
**Here is the "while true" loop that is waiting for the correct user input.**
```
user_choice = input(prompt).strip().lower()
```
**This is the variable handling the user input. It is stripped and lowercase to make sure that no mistakes are made.**
```
if user_choice in ["yes", "no"]:
    return user_choice
else:
    print(error_message)
```
**Here is the "if-else" for checking if the user input is "yes" or "no". If it is not, then print an error.**

## *user_filter_transaction(transactions: pd.DataFrame) -> List[Tuple[str, str]]*:
```
column_names = [column for column in transactions.columns]
number_of_columns = len(column_names)
number_of_filters_used = 1
filters_used = list()

add_filter_to_list(filters_used, column_names)

while number_of_filters_used < number_of_columns:
    choice = get_yes_no_choice(
        "\nDo you want to add another filter?\nEnter 'yes' or 'no': ")
    if choice.lower() == "yes":
        add_filter_to_list(filters_used, column_names)

        number_of_filters_used += 1
    else:
        break

return filters_used
```
**Function is asking the user for the filters and returns the list of it.**
```
column_names = [column for column in transactions.columns]
```
**This is the variable storing the list of column names from our DataFrame.**
```
number_of_columns = len(column_names)
number_of_filters_used = 1
filters_used = list()
```
**Those are another initial variables. One for storing the number of columns, one for initiating the number of filters (there is one already, because this function is called, so we used one filter), and one for creating a list of used filters to return at the end of the function.**
```
add_filter_to_list(filters_used, column_names)
```
**This is just another function called for adding the filter to the "filters_used" list.**
```
while number_of_filters_used < number_of_columns:
```
**This is a "while" loop for checking if the user is not filtering more columns than actually exist.**
```
choice = get_yes_no_choice(
    "\nDo you want to add another filter?\nEnter 'yes' or 'no': ")
if choice.lower() == "yes":
    add_filter_to_list(filters_used, column_names)

    number_of_filters_used += 1
else:
    break
```
**Program is asking the user if another filters are needed. Another function is used for it.**
**If the choice is "yes", then just add another filter to the list and increment the "number_of_filter_used".**
**If the choice is "no", then break out of the loop and return the list.**

## *get_filter_column(column_names: List[str], filters_used: Optional[List[Tuple[str, str]]] = None) -> str*:
```
prompt = "Choose the column to filter: "

while True:
    user_choice = get_choice(prompt, column_names)

    if user_choice not in [item[0] for item in filters_used]:
        break

    print("Sorry, you are already using this column.")

return user_choice
```
**Function is checking if the column name is used or not and returns it when it is not used.**
```
prompt = "Choose the column to filter: "
```
**This is a hard coded prompt for the further usage.**
```
while True:
```
**Another "while-true" loop. This one is for getting the proper column name.**
```
user_choice = get_choice(prompt, column_names)
```
**Get the column name using another function for it.**
```
if user_choice not in [item[0] for item in filters_used]:
    break

print("Sorry, you are already using this column.")
```
**If the user column is not already used, then break out of loop and return it. Otherwise print an error message and try again.**

## *add_filter_to_list(filter_list, column_names: List[str]) -> None*:
```
filter_column = get_filter_column(column_names, filter_list)
filter_row = input(
    "Enter the value that you want to search: "
).strip()

filter_data = (filter_column, filter_row)

filter_list.append(filter_data)
```
**Function that adds the filter to the list of filters.**
```
filter_column = get_filter_column(column_names, filter_list)
```
**This variable stores the column name to filter. It gets this column name by another function.**
```
filter_row = input(
    "Enter the value that you want to search: "
).strip()
```
**Get the value that you want to filter and strip it to avoid some mistakes.**
```
filter_data = (filter_column, filter_row)

filter_list.append(filter_data)
```
**First create a tuple to organize data, and then append this tuple to the "filter_list".**

## *get_choice(prompt: str, options_to_choose: List[str]) -> str*:
```
while True:
    print(f"\n{prompt}\n")

    for i, option in enumerate(options_to_choose, start=1):
        print(f"{i}. {option}")
    print("")

    try:
        choice = int(input("Enter the number: "))

        if 1 <= choice <= len(options_to_choose):
            return options_to_choose[choice - 1]
        else:
            print("Invalid choice. Please enter a number from the list.")
    except ValueError:
        print("Invalid input. Please enter a number.")
```
**A "While True" loop to get a correct choice from the list of choices.**
```
print(f"\n{prompt}\n")
```
**First print a prompt for user to know what to do.**
```
for i, option in enumerate(options_to_choose, start=1):
    print(f"{i}. {option}")
print("")
```
**Enumerate every option to print all options in format like this:**
1. *Option 1*
2. *Option 2*
**Program starts from 1 and print an empty line at the end. It is just for the style purpose.**
```
try:
    choice = int(input("Enter the number: "))

    if 1 <= choice <= len(options_to_choose):
        return options_to_choose[choice - 1]
    else:
        print("Invalid choice. Please enter a number from the list.")
except ValueError:
    print("Invalid input. Please enter a number.")
```
**Program tries to get the correct number for the option. If the number is not correct, then print an error and try again.**
```
choice = int(input("Enter the number: "))
```
**Take an input and convert it to "int".**
```
if 1 <= choice <= len(options_to_choose):
    return options_to_choose[choice - 1]
else:
    print("Invalid choice. Please enter a number from the list.")
```
**The number should not be less than 1 and more than the amount of options to choose.**
**If it is correct, then return the proper option. It will be the user choice - 1, because of the indexing starting from 0.**
**In case of mistake, just return an error message and retry.**

## *user_sort_transaction(transactions: pd.DataFrame) -> Tuple[str, bool]*:
```
prompt_sort = "What column do you want to sort?"
prompt_asc_desc = "Do you want to sort in ascending or descending order (the first row is at the bottom)?"
column_names = [column for column in transactions.columns]

choice_sort = get_choice(prompt_sort, column_names)
choice_asc_desc = get_choice(prompt_asc_desc, ["ascending", "descending"])

return choice_sort, False if choice_asc_desc == "ascending" else True
```
**This function is handling the sorting.**
```
prompt_sort = "What column do you want to sort?"
prompt_asc_desc = "Do you want to sort in ascending or descending order (the first row is at the bottom)?"
```
**Those are prompts. "prompt_sort" asks about the column and "prompt_asc_desc_" asks about the order (ascending or descending). bottom row is the first, because it is easier to read that way. User don't have to go up all the way to see the first record.**
```
column_names = [column for column in transactions.columns]
```
**Here program unpack the column names from the DataFrame into the "column_names" variable.**
```
choice_sort = get_choice(prompt_sort, column_names)
choice_asc_desc = get_choice(prompt_asc_desc, ["ascending", "descending"])
```
**Here the program uses the "get_choice" function to get the column to sort and the order (ascending, descending).**
```
return choice_sort, False if choice_asc_desc == "ascending" else True
```
**Here the program returns the tuple containing two variables. First is the column that we want to sort, and the second is boolean value. Ascending and descending is reversed, because the first row is at the bottom.**

## *generate_report(transactions: pd.DataFrame) -> None*:
```
start_date = get_date("Enter the start date (YYYY-MM-DD): ")

while True:
    end_date = get_date("Enter the end date (YYYY-MM-DD): ")

    if end_date >= start_date:
        break

    print("End date cannot be earlier than start date.")

report = prepare_report(transactions, start_date, end_date)

report.to_csv("report.csv", index=False)

print(f"\nReport saved as 'report.csv'. Do you want to display it here?\n")
choice = get_yes_no_choice("Enter 'yes' or 'no': ")

if choice.lower() == "yes":
    print(
        f"\n\n{report.to_string(index=False)}\n\n"
    )
```
**This function is generating a report about the transactions. There will be total income and outcome and the last value will be the income + outcome as whole. Program is also saving this report in the csv file.**
```
start_date = get_date("Enter the start date (YYYY-MM-DD): ")
```
**Program is getting date from the user. "get_date" function is handling this.**
```
while True:
    end_date = get_date("Enter the end date (YYYY-MM-DD): ")

    if end_date >= start_date:
        break

    print("End date cannot be earlier than start date.")
```
**Next will be the "while True" loop to get the correct data. Start date cannot be bigger than the end date (for example start date cannot be 02.01.2024 when the end date is 01.01.2024)**
```
end_date = get_date("Enter the end date (YYYY-MM-DD): ")
```
**Get the end date just like it did with the start date.**
```
if end_date >= start_date:
    break

print("End date cannot be earlier than start date.")
```
**If the end date is bigger than the start date, then continue the program, otherwise print the error and retry.**
```
report = prepare_report(transactions, start_date, end_date)

report.to_csv("report.csv", index=False)
```
**Prepare the report and assign it to the "report" variable. Another function is handling this.**
**If report is ready, then save it as the .csv file.**
```
print(f"\nReport saved as 'report.csv'. Do you want to display it here?\n")
choice = get_yes_no_choice("Enter 'yes' or 'no': ")
```
**Inform the user about saving the report as .csv file, then ask about displaying it in the console.**
**Get the answer from the user using the another function.**
```
if choice.lower() == "yes":
    print(
        f"\n\n{report.to_string(index=False)}\n\n"
    )
```
**Display the report if user writes "yes".**

## *get_date(prompt: str) -> datetime*:
```
while True:
    date_input = input(f"\n{prompt}")
    try:
        date_object = datetime.strptime(date_input, "%Y-%m-%d")
        return date_object
    except ValueError:
        print("Invalid date format. Please use the format 'YYYY-MM-DD'.")
```
**Another "while True" loop. This one is for getting correct date.**
```
date_input = input(f"\n{prompt}")
```
**use the prompt to get the date from the user.**
```
try:
    date_object = datetime.strptime(date_input, "%Y-%m-%d")
    return date_object
except ValueError:
    print("Invalid date format. Please use the format 'YYYY-MM-DD'.")
```
**Try to get the date. Print an error otherwise and retry.**
```
date_object = datetime.strptime(date_input, "%Y-%m-%d")
return date_object
```
**Convert the input to the date format (YYYY-MM-DD), then return the date.**
```
print("Invalid date format. Please use the format 'YYYY-MM-DD'.")
```
**Just print the error if there is an ValueError.**

## *prepare_report(data: pd.DataFrame, start_date: datetime, end_date: datetime) -> pd.DataFrame*:
```
data["date"] = pd.to_datetime(data["date"])

end_date = end_date + pd.Timedelta(days=1) - pd.Timedelta(seconds=1)

filtered_data = data[
    (data["date"] >= start_date) & (data["date"] <= end_date)
]
filtered_data.loc[:, "amount"] = filtered_data["amount"].replace(
    '[\$,]', '', regex=True
).astype(float)

income_sum = filtered_data[
    filtered_data["category"] == "income"]["amount"].sum()
outcome_sum = filtered_data[
    filtered_data["category"] == "outcome"]["amount"].sum()

summary = pd.DataFrame({
    "Category": ["Income", "Outcome", "Summary"],
    "Total Amount": [
        format_currency(
            income_sum, "USD", locale="en_US"
        ), format_currency(
            outcome_sum, "USD", locale="en_US"
        ), format_currency(
            income_sum + outcome_sum, "USD", locale="en_US"
        )
    ]
})

return summary
```
**This function is preparing the report and returns the DataFrame as the output.**
```
data["date"] = pd.to_datetime(data["date"])
```
**Convert the "date" column to the real date**
```
end_date = end_date + pd.Timedelta(days=1) - pd.Timedelta(seconds=1)
```
**Make sure to include rows even from the end of the day.**
```
filtered_data = data[
    (data["date"] >= start_date) & (data["date"] <= end_date)
]
```
**Get the filtered data from the start date including to end date including.**
```
filtered_data.loc[:, "amount"] = filtered_data["amount"].replace(
    '[\$,]', '', regex=True
).astype(float)
```
**Get rid of every special sign in "amount" column and change the value to pure float.**
```
income_sum = filtered_data[
    filtered_data["category"] == "income"]["amount"].sum()
outcome_sum = filtered_data[
    filtered_data["category"] == "outcome"]["amount"].sum()
```
**We have two variables here. "income_sum" and "outcome_sum".**
**"income_sum" will filter given data to select only the income amount, and then sum it.**
**"outcome_sum" will do the same to select only the outcome, and then sum it too.**
```
summary = pd.DataFrame({
    "Category": ["Income", "Outcome", "Summary"],
    "Total Amount": [
        format_currency(
            income_sum, "USD", locale="en_US"
        ), format_currency(
            outcome_sum, "USD", locale="en_US"
        ), format_currency(
            income_sum + outcome_sum, "USD", locale="en_US"
        )
    ]
})
```
**Create the summary DataFrame with "Category" and "Total Amount" columns.**
**The "Category" column will contain "Income", "Outcome" and "Summary" values.**
**The "Total Amount" column will contain the sum of the income, sum of the outcome and summary of both values. All three values formatted like a currency.**
```
return summary
```
**At the end just return the summary DataFrame that program made.**

## Conclusion
**So that is all about this code. Thank you for reading all of these. I hope that everything is kinda clear. I've had a lot of fun creating this program and I've learnt a lot about style, libraries and organization. I wanted to create a simple finance manager for income and outcome monitoring and I made it :D You can add rows, view rows, sort, filter and generate a report. Everything is saving on the hard drive and is ready to display at any time if you need it. Thank you for your course and have a nice day!**
