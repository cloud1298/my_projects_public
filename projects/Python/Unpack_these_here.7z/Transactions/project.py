import sys
import pandas as pd
from datetime import datetime
import re
from babel.numbers import format_currency
from typing import List, Tuple, Optional


def main():
    # Create a "transactions" data structure if there is not one available
    try:
        transactions = pd.read_csv("transactions.csv")
    except FileNotFoundError:
        transactions = pd.DataFrame(
            columns=["name", "category", "amount", "date"]
        )

    while True:
        print_options()
        user_decision = input("Enter the number: ").strip()

        match user_decision:
            case "1":
                # Get the details of the transaction
                name, category, amount, date = get_transaction_details()

                # Use the details and save the transaction
                transactions = add_transaction(
                    transactions, name, category, amount, date
                )
            case "2":
                view_transaction(transactions)
            case "3":
                generate_report(transactions)
            case "4":
                print("Exiting program...")
                sys.exit(0)
            case _:
                print("\nInvalid option. Please try again.\n")


def print_options() -> None:
    print("Choose the number:\n")
    print("1. Create a new transaction")
    print("2. View transaction list")
    print("3. Generate a financial report")
    print("4. Exit program\n")


def get_transaction_details() -> tuple:
    # Get the name
    name = input("Enter the transaction name: ").strip()

    # Get the category
    category = get_category_choice()

    # Get the amount
    amount = get_amount(category)

    # Get the date
    date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    return name, category, amount, date


def get_amount(category: str) -> float:
    # Get the amount of money
    amount = get_float_with_two_decimals("Enter the amount of dollars: ")
    print()

    if category == "income":
        return format_currency(amount, "USD", locale="en_US")
    elif category == "outcome":
        return format_currency(-amount, "USD", locale="en_US")


def get_float_with_two_decimals(prompt: str) -> float:
    # Pattern is any correct amount of money. For example: 23.45 or 23.4
    pattern = r"^\d+(\.\d{1,2})?$"

    while True:
        user_input = input(prompt)
        # If user input is a correct amount of money, then proceed, else print an error message
        if re.match(pattern, user_input):
            value = float(user_input)
            try:
                # If money is not bigger than 99 000 000 000, then return the value
                if value <= 99000000000:
                    return value

                # Raise a ValueError if money value is larger than it should be
                raise ValueError
            except ValueError:
                print("Invalid value. Max amount is $99 000 000 000.")
        else:
            print(
                "Invalid value. Enter a number with two or one decimal digits. Example: 12.34"
            )


def get_category_choice() -> str:
    # Get the category choice (income, outcome)
    options = ["income", "outcome"]
    prompt = "Choose a category: "

    return get_choice(prompt, options)


def add_transaction(
    transactions: pd.DataFrame,
    name: str,
    category: str,
    amount: format_currency,
    date: str,
) -> pd.DataFrame:
    new_transaction = {
        "name": name,
        "category": category,
        "amount": amount,
        "date": date,
    }

    # Add new transaction to the database
    transactions.loc[len(transactions)] = new_transaction

    # Save the updated database to file
    transactions.to_csv("transactions.csv", index=False)

    return transactions


def view_transaction(transactions: pd.DataFrame) -> None:
    # Get filter and sort data from the user
    filter, sort = user_display_customize(transactions)

    max_rows = get_max_display()

    # If user wants to filter data
    print("\n")
    if filter:
        filtered_data = transactions

        # Unpack every filter into column and value and use it to apply a filter to the data
        for col, val in filter:
            filtered_data = filtered_data[filtered_data[col].str.contains(
                val, case=False, na=False
            )]

        if filtered_data.empty:
            print("\nNO DATA FOUND\n")
        else:
            if sort:
                # Print data filtered and sorted
                print(
                    filtered_data.sort_values(
                        by=sort[0], ascending=sort[1]
                    ).head(max_rows).to_string(
                        index=False
                    )
                )

            else:
                # Print data only filtered
                print(
                    filtered_data.head(max_rows).to_string(
                        index=False
                    )
                )
    elif sort:
        # Print data only sorted
        print(
            transactions.sort_values(
                by=sort[0], ascending=sort[1]
            ).head(max_rows).to_string(
                index=False
            )
        )
    else:
        # Print unchanged data
        print(
            transactions.head(max_rows).to_string(
                index=False
            )
        )
    print("\n")


def get_max_display():
    while True:
        try:
            rows_to_display = int(
                input("\nHow many rows do you want to display: ")
            )
            if rows_to_display > 0:
                return rows_to_display

            raise ValueError
        except ValueError:
            print("Invalid amount. You must provide a positive number bigger than 0.\n")


def user_display_customize(transactions: pd.DataFrame) -> tuple[tuple[str, str], tuple[str, str]]:
    filter, sort = None, None

    if get_yes_no_choice("\nDo you want to filter the database?\nEnter 'yes' or 'no': ") == "yes":
        filter = user_filter_transaction(transactions)

    if get_yes_no_choice("\nDo you want to sort the database?\nEnter 'yes' or 'no': ") == "yes":
        sort = user_sort_transaction(transactions)

    return filter, sort


def get_yes_no_choice(prompt: str) -> str:
    error_message = "Please, enter a valid answer."

    while True:
        user_choice = input(prompt).strip().lower()
        if user_choice in ["yes", "no"]:
            return user_choice
        else:
            print(error_message)


def user_filter_transaction(transactions: pd.DataFrame) -> List[Tuple[str, str]]:
    # Get all column names
    column_names = [column for column in transactions.columns]
    number_of_columns = len(column_names)
    # Already used 1 filter to initiate this function, so it is set to 1
    number_of_filters_used = 1
    filters_used = list()

    add_filter_to_list(filters_used, column_names)

    # Loop only if user is not using more filters than columns
    while number_of_filters_used < number_of_columns:
        choice = get_yes_no_choice(
            "\nDo you want to add another filter?\nEnter 'yes' or 'no': ")
        if choice.lower() == "yes":
            add_filter_to_list(filters_used, column_names)

            # Another filter added
            number_of_filters_used += 1
        else:
            break

    return filters_used


def get_filter_column(column_names: List[str], filters_used: Optional[List[Tuple[str, str]]] = None) -> str:
    prompt = "Choose the column to filter: "

    while True:
        # Get column name
        user_choice = get_choice(prompt, column_names)

        # "filter_used" contains a list of tuples, so it is like [(column, value), (column, value)]
        # Program is making a list of columns containing used filters ([column, column]) to check if the filter is not already added to the list of filters
        if user_choice not in [item[0] for item in filters_used]:
            break

        # There is already a filter added to the list of filters
        print("Sorry, you are already using this column.")

    return user_choice


def add_filter_to_list(filter_list, column_names: List[str]) -> None:
    filter_column = get_filter_column(column_names, filter_list)
    filter_row = input(
        "Enter the value that you want to search: "
    ).strip()

    filter_data = (filter_column, filter_row)

    filter_list.append(filter_data)


def get_choice(prompt: str, options_to_choose: List[str]) -> str:
    while True:
        # Print a message
        print(f"\n{prompt}\n")

        # Print the options with their corresponding numbers
        for i, option in enumerate(options_to_choose, start=1):
            print(f"{i}. {option}")
        print("")

        try:
            choice = int(input("Enter the number: "))

            # Return option chosen by the user if the option is valid
            if 1 <= choice <= len(options_to_choose):
                return options_to_choose[choice - 1]
            else:
                print("Invalid choice. Please enter a number from the list.")
        except ValueError:
            print("Invalid input. Please enter a number.")


def user_sort_transaction(transactions: pd.DataFrame) -> Tuple[str, bool]:
    prompt_sort = "What column do you want to sort?"
    prompt_asc_desc = "Do you want to sort in ascending or descending order (the first row is at the bottom)?"
    column_names = [column for column in transactions.columns]

    choice_sort = get_choice(prompt_sort, column_names)
    choice_asc_desc = get_choice(prompt_asc_desc, ["ascending", "descending"])

    return choice_sort, False if choice_asc_desc == "ascending" else True


def generate_report(transactions: pd.DataFrame) -> None:
    start_date = get_date("Enter the start date (YYYY-MM-DD): ")

    while True:
        end_date = get_date("Enter the end date (YYYY-MM-DD): ")

        if end_date >= start_date:
            break

        print("End date cannot be earlier than start date.")

    report = prepare_report(transactions, start_date, end_date)

    report.to_csv("report.csv", index=False)

    print(f"\nReport saved as 'report.csv'. Do you want to display it here?\n")
    choice = get_yes_no_choice("Enter 'yes' or 'no': ")

    if choice.lower() == "yes":
        print(
            f"\n\n{report.to_string(index=False)}\n\n"
        )


def get_date(prompt: str) -> datetime:
    while True:
        date_input = input(f"\n{prompt}")
        try:
            # Transform user input into date format
            date_object = datetime.strptime(date_input, "%Y-%m-%d")
            return date_object
        except ValueError:
            print("Invalid date format. Please use the format 'YYYY-MM-DD'.")


def prepare_report(data: pd.DataFrame, start_date: datetime, end_date: datetime) -> pd.DataFrame:
    # Change column format from str into date
    data["date"] = pd.to_datetime(data["date"])

    end_date = end_date + pd.Timedelta(days=1) - pd.Timedelta(seconds=1)

    filtered_data = data[
        # Apply filter to get only rows from start_date to end_date
        (data["date"] >= start_date) & (data["date"] <= end_date)
    ]
    filtered_data.loc[:, "amount"] = filtered_data["amount"].replace(
        '[\$,]', '', regex=True
    ).astype(float)

    income_sum = filtered_data[
        filtered_data["category"] == "income"]["amount"].sum()
    outcome_sum = filtered_data[
        filtered_data["category"] == "outcome"]["amount"].sum()

    summary = pd.DataFrame({
        "Category": ["Income", "Outcome", "Summary"],
        "Total Amount": [
            format_currency(
                income_sum, "USD", locale="en_US"
            ), format_currency(
                outcome_sum, "USD", locale="en_US"
            ), format_currency(
                income_sum + outcome_sum, "USD", locale="en_US"
            )
        ]
    })

    return summary


if __name__ == '__main__':
    main()
