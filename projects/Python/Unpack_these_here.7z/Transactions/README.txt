# Personal Finance Tracker

## Overview
A command-line Python program for tracking personal financial transactions. Users can add income and expense transactions, view them with filtering and sorting options, and generate financial reports over a specified date range.

## Features
- Add transactions (name, category, amount, date)
- View transactions with customizable filters and sorting
- Generate financial reports with income, outcome, and net summary
- Saves data to `transactions.csv` and reports to `report.csv`
- Input validation for amounts and dates

## Prerequisites
- Python 3.x
- Pandas (`pip install pandas`)
- Babel (`pip install babel`)

## Usage
1. Run the script: python finance_tracker.py
2. Choose an option:
   - **1**: Add a transaction (name, category [income/outcome], amount)
   - **2**: View transactions (filter by column/value, sort, set row limit)
   - **3**: Generate a report (specify date range, view/save summary)
   - **4**: Exit
3. Follow prompts for input.

## Technical Details
- Built with Python
- Uses `pandas` for data management
- `babel.numbers` for USD currency formatting
- Stores data in CSV files
- Regex for amount validation
- Type hints with `typing`

## Notes
- Transactions are stored in `transactions.csv` (created if not found)
- Amounts limited to $99 billion, with 1-2 decimal places
- Dates auto-set to current timestamp for new transactions
- Reports saved as `report.csv` with optional display
- Requires valid YYYY-MM-DD format for report dates