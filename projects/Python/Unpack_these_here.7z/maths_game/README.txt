# Math Quiz Game

## Overview
A simple command-line math quiz game written in Python. Players answer a series of randomly generated math questions involving addition, subtraction, multiplication, and division, with integers between 1 and 10.

## Features
- Generates 4 random math questions
- Supports addition (+), subtraction (-), multiplication (*), and integer division (/)
- Tracks and displays the player's score
- Provides feedback on each answer
- Evaluates performance at the end

## Prerequisites
- Python 3.x


## Usage
1. Run the script: python quiz.py
2. Answer each of the 4 questions by typing an integer.
3. Receive immediate feedback on each answer.
4. View your final score and performance message.

## Configuration
- `MIN_NUMBER = 1`: Minimum number for questions
- `MAX_NUMBER = 10`: Maximum number for questions
- `NUMBER_OF_QUESTIONS = 4`: Total questions in the quiz

## Technical Details
- Built with Python
- Uses `random` module for question generation
- Handles invalid input (non-integers) with try-except
- Avoids division by zero with a while loop
- Integer division (`//`) used for division operations

## Notes
- Answers must be integers
- Division results are rounded down to the nearest integer
- No external dependencies required