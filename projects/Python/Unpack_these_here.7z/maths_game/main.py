import random

MIN_NUMBER = 1
MAX_NUMBER = 10
NUMBER_OF_QUESTIONS = 4


def main():
    score = 0
    current_question_number = 0
    half_of_questions = int(NUMBER_OF_QUESTIONS / 2)

    for _ in range(NUMBER_OF_QUESTIONS):
        # Increment the question number at the start of the loop so it goes from 1 to MAX_NUMBER.
        current_question_number += 1

        # Writes the text to inform the user about the current question.
        write_question_number(current_question_number, NUMBER_OF_QUESTIONS)

        # Gets the user's answer along with the correct answer and displays the randomly generated math question.
        answer, correct_answer = get_answer()

        # Writes if the answer is correct and also adds the score to the "score" variable.
        score = manage_score(answer, correct_answer, score)

    print_score(score, half_of_questions)


def write_question_number(current_number: int, total_number: int) -> None:
    print(f"\nQuestion n°{current_number} out of {total_number}:")


def get_answer() -> tuple[int, int]:
    # Generates a question.
    math_question, correct_answer = generate_question()

    # Try to get the correct answer (integer) from the user.
    while True:
        try:
            answer = int(input(math_question))
        except ValueError:
            print("The answer must be an integer.")
        else:
            return answer, correct_answer


def generate_question() -> tuple[str, int]:
    while True:
        try:
            # Generate a random number between min_number and max_number
            first_number = random.randint(MIN_NUMBER, MAX_NUMBER)
            second_number = random.randint(MIN_NUMBER, MAX_NUMBER)

            operations = {
                "+": lambda a, b: a + b,
                "-": lambda a, b: a - b,
                "*": lambda a, b: a * b,
                "/": lambda a, b: a // b
            }
            # Generate a random operation
            operation = random.choice(list(operations.keys()))

            question = f"{first_number} {operation} {second_number}"
            correct_answer = operations[operation](first_number, second_number)

            return f"Compute (only integers): {question} = ", correct_answer
        except ZeroDivisionError:
            pass


def manage_score(answer: int, correct_answer: int, score: int) -> int:
    if answer == correct_answer:
        print("Right answer")
        score += 1
    else:
        print(f"Wrong answer. The correct answer is: {correct_answer}.")

    return score


def print_score(score: int, half: int) -> None:
    print(f"\nYour points: {score} out of {NUMBER_OF_QUESTIONS}")

    if score == 0:
        print("You did very poorly :(")
    elif 0 < score < half:
        print("You did not do very well.")
    elif score == half:
        print("You answered half of the questions correctly!")
    elif half < score < NUMBER_OF_QUESTIONS:
        print("Very good! Most of the questions were correct!")
    else:
        print("Perfection!")


if __name__ == "__main__":
    main()
