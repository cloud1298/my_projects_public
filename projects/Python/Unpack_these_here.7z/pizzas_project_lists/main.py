import sys
from typing import Optional


def main():
    pizzas = ["4 cheeses", "vegetarian", "hawaii", "calzone"]

    add_user_pizza(pizzas)
    pizzas.sort()
    display(pizzas)


def display(collection: list) -> None:
    nb_pizza = len(collection)

    if nb_pizza != 0:
        display_pizzas(nb_pizza, collection)

        sys.exit(0)

    print("\nNo pizza")


def display_pizzas(number: int, pizzas: list, nb_to_display: int = None) -> None:
    pizzas_customized = customize_list(nb_to_display, pizzas)
    nb_pizzas = len(pizzas_customized)

    print(
        f"\n----- PIZZAS ({nb_pizzas}) -----"
    )

    for i in pizzas_customized:
        print(i)

    print(f"\nfirst pizza: {pizzas_customized[0]}")
    print(f"last pizza: {pizzas_customized[-1]}")


def customize_list(number: Optional[int], pizzas: list) -> None:
    if number is not None and (0 < number <= len(pizzas)):
        return pizzas[:number]
    elif number == 0:
        print("\nNo pizza to display")
        sys.exit(0)

    return pizzas


def add_user_pizza(pizzas: list) -> None:
    pizza = input("Add your pizza: ").strip().lower()

    if pizza in pizzas:
        print("\nERROR: This pizza already exists")
        return

    pizzas.append(pizza)


if __name__ == "__main__":
    main()
