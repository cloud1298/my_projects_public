# Pizza List Manager

## Overview
A simple command-line Python program that manages a list of pizza names. Users can add a new pizza to a predefined list, and the program displays the sorted list with details like the first and last pizza.

## Features
- Predefined list of pizzas
- Add a new pizza via user input
- Prevents duplicate pizza names
- Sorts and displays the pizza list
- Shows the total number of pizzas, first pizza, and last pizza

## Prerequisites
- Python 3.x

## Usage
1. Run the script: python pizza.py
2. Enter a pizza name when prompted (e.g., "pepperoni").
3. View the updated, sorted list of pizzas with additional details.

## Technical Details
- Built with Python
- Uses `sys` for program exit
- Typing hints with `typing.Optional`
- Case-insensitive pizza name comparison
- List sorting with `sort()`

## Notes
- Initial pizza list: "4 cheeses", "vegetarian", "hawaii", "calzone"
- Duplicate pizzas are rejected with an error message
- Empty list handling included
- User input is stripped of whitespace and converted to lowercase